/* ==========================================================================
   NAMMAROAD ECOSYSTEM SIMULATOR - INTERACTIVE JAVASCRIPT LOGIC
   ========================================================================== */

// --- NammaRoad English & Tamil Multi-Language Library Map ---
const langLib = {
  en: {
    headerTitle: "NammaRoad",
    headerTagline: "SAFER ROADS FOR EVERYONE",
    lblLiveStatus: "SIMULATOR ACTIVE",
    lblFirebaseConnected: "FIREBASE OK",
    lblClientAppTitle: "NammaRoad Application",
    lblClientAppSub: "Flutter APK Architecture Showcase",
    splashTagline: "“Safer Roads for Everyone”",
    splashDesc: "An AI-powered smart road safety and awareness application for Indian cities.",
    btnSplashGo: "Enter NammaRoad",
    lblSignInDesc: "Secure Client Authorization",
    lblEmail: "Email Address",
    lblPassword: "Password",
    lblForgot: "Forgot Password?",
    btnSignIn: "Sign In",
    lblOr: "OR CONTINUE WITH",
    btnGoogle: "Sign In with Google",
    lblNoAccount: "Don't have an account?",
    lblRegisterLink: "Register",
    lblWelcomeBack: "WELCOME BACK",
    lblScoreText: "SCORE",
    safetyQuoteText: '"Slow down! Your family is waiting for you at home."',
    safetyQuoteAuthor: "— NammaRoad Safety Tip",
    menuP1: "Safety Features",
    menuP2: "Rules & Fines",
    menuP3: "Pothole Report",
    menuP4: "AI Vision Hub",
    menuP5: "About Team",
    menuP6: "Sensor Graph",
    lblPhStat1: "Saved Trips",
    lblPhStat2: "Shock Scans",
    lblPhStat3: "RG Tokens",
    featuresTitle: "Road Safety Features",
    feat1Title: "Smart Caution Alerts",
    feat1Desc: "Integrated warning triggers cautioning drivers prior to approaching crash high-incidence spots or deep potholes.",
    feat2Title: "Real-time AI Driver Monitor",
    feat2Desc: "Understands driver alertness, blinking index rates, and yawns on the mobile front camera to prevent sleeping.",
    feat3Title: "Instant Sensor Crash SOS",
    feat3Desc: "Uses highly calibrated smartphone IMU sensors to discover high impact crashes and triggers golden hour alerts automatically.",
    feat4Title: "Smart City Integration",
    feat4Desc: "Direct API bridge reporting pavement degradation reports immediately to municipal road repair operations.",
    rulesTitle: "Traffic Rules & Fines",
    rule1Title: "Helmet Compulsory",
    rule1Fine: "Fine: ₹1,000 + 3 Month License Suspended",
    rule1Desc: "Both driver and pillion rider MUST wear ISI-marked safety helmets. Saves lives from head injuries.",
    rule2Title: "Seatbelt Compulsory",
    rule2Fine: "Fine: ₹1,000",
    rule2Desc: "All occupants in the car, including rear passengers, must fasten seatbelts at all times during transit.",
    rule3Title: "Speed Limit Compliance",
    rule3Fine: "Fine: ₹2,000 (LMV)",
    rule3Desc: "Strictly respect city speed indices (Chennai city: 60km/h max). Over-speeding is the cause of 72.3% of deaths.",
    rule4Title: "Mobile Usage Penalty",
    rule4Fine: "Fine: ₹5,000",
    rule4Desc: "Holding a phone, text messaging, or hand-held calls while driving leads to heavy penalties and instant distraction.",
    rule5Title: "Zero Drunk Driving",
    rule5Fine: "Fine: ₹10,000 / 6 Month Jail",
    rule5Desc: "Zero tolerance policy. Driving with blood alcohol levels exceeding 30mg per 100ml results in immediate imprisonment.",
    lblDoTitle: "DO'S",
    do1: "Keep left always",
    do2: "Use indicators",
    do3: "Give way to ambulance",
    lblDontTitle: "DON'TS",
    dont1: "No wrong-side driving",
    dont2: "Do not jump signals",
    dont3: "No tailgating vehicles",
    potholeTitle: "Geotag Pothole Report",
    lblGPSAuto: "GPS Auto-Location Active",
    lblPhotoUpload: "Tap to Capture / Upload Road Shock",
    lblSeverity: "Severity Level:",
    btnSubmitReport: "Submit to Firestore",
    visionTitle: "AI Vision HUD",
    lblVisionAIType: "DRIVER DROWSINESS MONITOR",
    lblDrowsyVoiceAlert: "FATIGUE ALERT: STAY AWAKE!",
    visionH4: "How NammaRoad AI works:",
    visionP: "TensorFlow Lite models run locally on the smartphone edge. Bypassing cloud latency, OpenCV matrices filter camera inputs, measuring Eye Aspect Ratios (EAR) and mouth height dimensions to identify driver fatigue in under 100 milliseconds.",
    aboutTitle: "About NammaRoad",
    aboutSolH4: "Our Vision",
    aboutSolP: "NammaRoad is a unified ecosystem combining crowd-sourced road telemetry, edge AI vision warning algorithms, and municipality dashboard dispatch software to eliminate road traffic mortalities across Indian smart cities.",
    lblFounders: "The Innovators",
    lblContact: "Reach Out",
    lblTelemetryHeader: "Sensor Fusion Hub",
    lblDialSpeed: "GNSS SPEED",
    lblDialGForce: "IMU IMPACT",
    lblShockPlotTitle: "SHOCK ACCELEROMETER (3-AXIS)",
    sosTitle: "Automatic Crash Detection",
    sosDesc: "If severe impact force exceeding 6.5G index is registered, NammaRoad automatically dispatches emergency GPS dispatches.",
    btnCrashTest: "Simulate G-Shock Impact",
    sosCountdownH: "CRASH FORCE DETECTED",
    sosCountdownDesc: "Sending GPS coordinates and severity reports to Golden Hour response hubs in 10s...",
    btnCancelSos: "FALSE ALARM - CANCEL",
    sosSuccessTitle: "RESCUE DISPATCHED",
    sosDispatchStatus: "Rescuers: Ambulance en route from closest government hospital",
    radarTitle: "Pulsing SOS Beacon",
    radarDesc: "Broadcasting GPS Geotag. Locating nearby Chennai Traffic Police stations...",
    btnRadarClose: "Dismiss Emergency Beacon",
    navHome: "Home",
    navPothole: "Report",
    navVision: "Vision",
    navSensor: "Sensor",
    lblCcTitle: "NammaRoad Central Smart-City Operations Dashboard",
    lblCcSub: "Centralized Maintenance, Dispatches & PostGIS Pothole Restoration Hub",
    lblCcKpi1: "Active Road Potholes",
    lblCcKpi2: "Asphalt Restorations",
    lblCcKpi3: "Golden Hour Rescues",
    lblCcKpi4: "Chennai Safety Rating",
    lblCcFeedTitle: "Live AI Vision & IMU Incident Activity Feed",
    lblCcTableTitle: "Active Road Restoration Work Tickets (Firestore Collection)",
    btnCcSimulateReport: "Simulate Citizen Pothole Geotag",
    lblThLocation: "Location Coordinates",
    lblThReport: "Report Category",
    lblThConfidence: "AI Confidence",
    lblThUrgency: "AI Urgency",
    lblThAction: "Action Dispatch",
    lblCcChart1Title: "Incident Analysis by Category",
    lblCcChart2Title: "Weekly Alert Spike Intensity",
    lblCcHotspotsTitle: "AI Predicted Accident Hotspots",
    drowsyVoiceSpeech: "Warning. You seem drowsy. Eye closure detected. Please pull over safely and take a break.",
    gpsMockAlert: "Obstacle Warning: Pothole detected ahead.",
    sosVoiceSpeech: "Severe crash force anomaly detected. Auto emergency golden hour SOS dispatches are being sent. Press cancel if this is a false alarm."
  },
  ta: {
    headerTitle: "நம்மரோடு",
    headerTagline: "அனைவருக்கும் பாதுகாப்பான சாலைகள்",
    lblLiveStatus: "சிமுலேட்டர் செயலில் உள்ளது",
    lblFirebaseConnected: "ஃபயர்பேஸ் இணைக்கப்பட்டுள்ளது",
    lblClientAppTitle: "நம்மரோடு செயலி",
    lblClientAppSub: "ஃப்ளட்டர் ஏ.பி.கே கட்டமைப்பு முன்னோட்டம்",
    splashTagline: "“அனைவருக்கும் பாதுகாப்பான சாலைகள்”",
    splashDesc: "இந்திய நகரங்களுக்கான செயற்கை நுண்ணறிவு அடிப்படையிலான ஸ்மார்ட் சாலை பாதுகாப்பு செயலி.",
    btnSplashGo: "நம்மரோடு உள்நுழையவும்",
    lblSignInDesc: "பாதுகாப்பான அங்கீகாரம்",
    lblEmail: "மின்னஞ்சல் முகவரி",
    lblPassword: "கடவுச்சொல்",
    lblForgot: "கடவுச்சொல் மறந்ததா?",
    btnSignIn: "உள்நுழைய",
    lblOr: "அல்லது இதன் மூலம் தொடரவும்",
    btnGoogle: "கூகிள் மூலம் உள்நுழைக",
    lblNoAccount: "கணக்கு இல்லையா?",
    lblRegisterLink: "பதிவு செய்க",
    lblWelcomeBack: "வரவேற்கிறோம்",
    lblScoreText: "மதிப்பெண்",
    safetyQuoteText: '"வேகத்தை குறையுங்கள்! உங்கள் குடும்பத்தினர் வீட்டில் உங்களுக்காக காத்திருக்கிறார்கள்."',
    safetyQuoteAuthor: "— நம்மரோடு பாதுகாப்பு குறிப்பு",
    menuP1: "பாதுகாப்பு அம்சங்கள்",
    menuP2: "விதிகள் & அபராதம்",
    menuP3: "பள்ளங்கள் அறிக்கை",
    menuP4: "ஏஐ விஷன் மையம்",
    menuP5: "குழுவை பற்றி",
    menuP6: "சென்சார் வரைபடம்",
    lblPhStat1: "சேமித்த பயணங்கள்",
    lblPhStat2: "அதிர்வு ஸ்கேன்கள்",
    lblPhStat3: "ஆர்.ஜி டோக்கன்கள்",
    featuresTitle: "சாலை பாதுகாப்பு அம்சங்கள்",
    feat1Title: "ஸ்மார்ட் எச்சரிக்கைகள்",
    feat1Desc: "அபாயகரமான விபத்து பகுதிகள் அல்லது ஆழமான சாலைப் பள்ளங்களை அணுகுவதற்கு முன்பு ஓட்டுநர்களை எச்சரிக்கும் தொழில்நுட்பம்.",
    feat2Title: "ஓட்டுநர் விழிப்புணர்வு கண்காணிப்பு",
    feat2Desc: "முன் கேமரா மூலம் ஓட்டுநரின் கண் சிமிட்டல் வீதம் மற்றும் கொட்டாவி விடுவதை கண்காணித்து தூங்குவதை தடுக்கிறது.",
    feat3Title: "தானியங்கி விபத்து கண்டறிதல் (SOS)",
    feat3Desc: "கைபேசியின் சென்சார்களைப் பயன்படுத்தி விபத்துக்களைக் கண்டறிந்து உடனடியாக அவசர உதவிகளைத் தொடர்பு கொள்கிறது.",
    feat4Title: "ஸ்மார்ட் சிட்டி ஒருங்கிணைப்பு",
    feat4Desc: "சாலையின் சேத விவரங்களை உடனடியாக மாநகராட்சி சாலை பழுதுபார்க்கும் பிரிவுக்கு நேரடியாக அனுப்பும் வசதி.",
    rulesTitle: "போக்குவரத்து விதிகள் & அபராதம்",
    rule1Title: "தலைக்கவசம் கட்டாயம்",
    rule1Fine: "அபராதம்: ₹1,000 + 3 மாத உரிமம் சஸ்பெண்ட்",
    rule1Desc: "இருசக்கர வாகன ஓட்டுநரும் பின்னால் அமர்ந்திருப்பவரும் ஐ.எஸ்.ஐ முத்திரை பெற்ற தலைக்கவசம் அணிய வேண்டும்.",
    rule2Title: "சீட் பெல்ட் கட்டாயம்",
    rule2Fine: "அபராதம்: ₹1,000",
    rule2Desc: "காரில் பயணம் செய்யும் அனைவரும், பின் இருக்கையில் அமர்ந்திருப்பவர்கள் உட்பட, சீட் பெல்ட் அணிய வேண்டும்.",
    rule3Title: "வேக வரம்பு இணக்கம்",
    rule3Fine: "அபராதம்: ₹2,000",
    rule3Desc: "நகர வேக வரம்புகளை மதிக்கவும் (சென்னை நகரம்: அதிகபட்சம் 60 கி.மீ/மணி). விபத்து மரணங்களில் 72.3% அதிக வேகத்தால் ஏற்படுகின்றன.",
    rule4Title: "கைபேசி பயன்பாடு தடையுறுத்தல்",
    rule4Fine: "அபராதம்: ₹5,000",
    rule4Desc: "வாகனம் ஓட்டும்போது கைபேசியை கையில் பிடித்தல், குறுஞ்செய்தி அனுப்புதல் அல்லது பேசுவது தண்டனைக்குரியது.",
    rule5Title: "மது அருந்தி ஓட்டுதல் தடை",
    rule5Fine: "அபராதம்: ₹10,000 / 6 மாத சிறை",
    rule5Desc: "பூஜ்ஜிய சகிப்புத்தன்மை கொள்கை. இரத்தத்தில் ஆல்கஹால் அளவு 30 மில்லிகிராமிற்கு மேல் இருந்தால் உடனடியாக சிறைத்தண்டனை.",
    lblDoTitle: "செய்ய வேண்டியவை",
    do1: "எப்போதும் இடதுபுறம் செல்லவும்",
    do2: "சிக்னல் விளக்குகளை பயன்படுத்தவும்",
    do3: "ஆம்புலன்ஸுக்கு வழி விடுங்கள்",
    lblDontTitle: "செய்யக்கூடாதவை",
    dont1: "எதிர் திசையில் ஓட்ட வேண்டாம்",
    dont2: "போக்குவரத்து சிக்னலை மீறாதீர்",
    dont3: "முன்னால் செல்லும் வாகனத்தை ஒட்டாதீர்",
    potholeTitle: "சாலையின் பள்ளம் அறிக்கை",
    lblGPSAuto: "ஜி.பி.எஸ் தானியங்கி இருப்பிடம் செயலில் உள்ளது",
    lblPhotoUpload: "புகைப்படம் எடுக்கவும் / சாலையின் சேதத்தை பதிவேற்றவும்",
    lblSeverity: "தீவிரத்தன்மை அளவு:",
    btnSubmitReport: "ஃபயர்பேஸில் பதிவேற்றவும்",
    visionTitle: "ஏஐ விஷன் கேமரா",
    lblVisionAIType: "ஓட்டுநர் விழிப்புணர்வு கண்காணிப்பு",
    lblDrowsyVoiceAlert: "எச்சரிக்கை: விழிப்புடன் இருக்கவும்!",
    visionH4: "நம்மரோடு ஏஐ வேலை செய்யும் விதம்:",
    visionP: "டென்சர்ஃப்ளோ லைட் மாதிரிகள் கைபேசியிலேயே இயங்குகின்றன. மேகக்கணி தாமதத்தைத் தவிர்த்து, ஓபன்சிவி கேமரா உள்ளீடுகளை வடிகட்டி, கண் சிமிட்டல் மற்றும் கொட்டாவியைக் கண்டறிந்து 100 மில்லிசெகண்டிற்குள் எச்சரிக்கிறது.",
    aboutTitle: "நம்மரோடு பற்றி",
    aboutSolH4: "எங்கள் தொலைநோக்கு",
    aboutSolP: "நம்மரோடு என்பது விபத்து இல்லாத ஸ்மார்ட் நகரங்களை உருவாக்குவதற்காக சாலை தரவு, செயற்கை நுண்ணறிவு எச்சரிக்கைகள் மற்றும் மாநகராட்சி பழுதுபார்க்கும் பிரிவை இணைக்கும் ஒரு ஒருங்கிணைந்த அமைப்பாகும்.",
    lblFounders: "கண்டுபிடிப்பாளர்கள்",
    lblContact: "தொடர்பு கொள்ள",
    lblTelemetryHeader: "சென்சார் ஒருங்கிணைப்பு",
    lblDialSpeed: "ஜிஎன்எஸ்எஸ் வேகம்",
    lblDialGForce: "சென்சார் அதிர்வு",
    lblShockPlotTitle: "அதிர்வு அளவீடு (3-அச்சு)",
    sosTitle: "தானியங்கி விபத்து கண்டறிதல்",
    sosDesc: "விபத்து அதிர்வு 6.5ஜி அளவுக்கு அதிகமாக இருந்தால், நம்மரோடு தானியங்கியாக அவசர உதவி எண்களுக்கு தகவல் அனுப்பும்.",
    btnCrashTest: "விபத்து அதிர்வை சோதிக்கவும்",
    sosCountdownH: "விபத்து அதிர்வு கண்டறியப்பட்டது",
    sosCountdownDesc: "அவசர உதவி மையங்களுக்கு ஜிபிஎஸ் மற்றும் மருத்துவ விவரங்கள் 10 வினாடிகளில் அனுப்பப்படும்...",
    btnCancelSos: "தவறான எச்சரிக்கை - ரத்து செய்க",
    sosSuccessTitle: "அவசர உதவி அனுப்பப்பட்டது",
    sosDispatchStatus: "மீட்பாளர்கள்: ஆம்புலன்ஸ் அரசு மருத்துவமனையிலிருந்து புறப்பட்டு விட்டது",
    radarTitle: "அவசர சிக்னல்",
    radarDesc: "ஜிபிஎஸ் ஒளிபரப்பப்படுகிறது. அருகிலுள்ள சென்னை போக்குவரத்து காவல் நிலையங்கள் கண்டறியப்படுகின்றன...",
    btnRadarClose: "அவசர சிக்னலை மூடுக",
    navHome: "முகப்பு",
    navPothole: "அறிக்கை",
    navVision: "விஷன்",
    navSensor: "சென்சார்",
    lblCcTitle: "நம்மரோடு ஸ்மார்ட் சிட்டி மாநகராட்சி செயல்பாட்டு மையம்",
    lblCcSub: "சாலை பராமரிப்பு மற்றும் அவசர மீட்பு மேலாண்மை தளம்",
    lblCcKpi1: "செயலில் உள்ள சாலைப் பள்ளங்கள்",
    lblCcKpi2: "பழுதுபார்க்கப்பட்ட சாலைகள்",
    lblCcKpi3: "அவசர மீட்புகள்",
    lblCcKpi4: "சென்னை பாதுகாப்பு மதிப்பீடு",
    lblCcFeedTitle: "நேரடி ஏஐ விஷன் & அதிர்வு செயல்பாட்டு பதிவுகள்",
    lblCcTableTitle: "செயலில் உள்ள சாலை பழுதுபார்ப்பு டிக்கெட்டுகள் (ஃபயர்பேஸ் கலெக்ஷன்)",
    btnCcSimulateReport: "பள்ளம் அறிக்கையை சிமுலேட் செய்க",
    lblThLocation: "இருப்பிட ஒருங்கிணைப்புகள்",
    lblThReport: "அறிக்கை வகை",
    lblThConfidence: "ஏஐ நம்பிக்கை",
    lblThUrgency: "ஏஐ அவசரம்",
    lblThAction: "நடவடிக்கை",
    lblCcChart1Title: "வகை வாரியான விபத்து பகுப்பாய்வு",
    lblCcChart2Title: "வாராந்திர எச்சரிக்கை அதிர்வு தீவிரம்",
    lblCcHotspotsTitle: "விபத்து நிகழக்கூடிய கணிப்பு பகுதிகள்",
    drowsyVoiceSpeech: "எச்சரிக்கை! உங்களுக்கு தூக்கம் வருகிறது. தயவுசெய்து வண்டியை பாதுகாப்பாக நிறுத்திவிட்டு ஓய்வெடுக்கவும்.",
    gpsMockAlert: "எச்சரிக்கை: முன்னால் சாலையின் பள்ளம் உள்ளது.",
    sosVoiceSpeech: "விபத்து அதிர்வு கண்டறியப்பட்டது. தானியங்கி அவசர உதவி சிக்னல் அனுப்பப்படுகிறது. இது தவறான எச்சரிக்கையாக இருந்தால் கேன்சல் செய்யவும்."
  }
};

// --- App State Configuration ---
const state = {
  lang: 'en',
  voiceAssistant: true,
  activeMobileScreen: 'screenSplash',
  leafletMap: null,
  mapMarkers: [],
  webcamActive: false,
  webcamStream: null,
  imuChart: null,
  imuData: { x: [], y: [], z: [] },
  simulatedDrowsiness: false,
  sosCountdown: 10,
  sosTimerId: null,
  audioCtx: null,
  activeSeverity: 'Low',
  adminKPIs: {
    potholes: 487,
    repairs: 342,
    rescues: 18,
    safetyIndex: 91.4
  },
  mockTickets: [
    { id: 'TKT-9204', lat: 13.0850, lng: 80.2680, type: 'Critical Pothole', confidence: '98%', urgency: 'CRITICAL', road: 'Poonamallee High Rd' },
    { id: 'TKT-9198', lat: 13.0420, lng: 80.2520, type: 'Multiple Potholes', confidence: '84%', urgency: 'MEDIUM', road: 'Anna Salai (Teynampet)' },
    { id: 'TKT-9195', lat: 13.0110, lng: 80.2200, type: 'Wrong-side Driving', confidence: '92%', urgency: 'HIGH', road: 'Kathipara Interchange' },
    { id: 'TKT-9189', lat: 13.0710, lng: 80.2010, type: 'Minor Pothole', confidence: '71%', urgency: 'LOW', road: 'Koyambedu Bypass' }
  ],
  activeCodeTab: 'flutterApp'
};

// --- App Launch Init ---
document.addEventListener('DOMContentLoaded', () => {
  initClock();
  initAudio();
  initLeafletMap();
  initAnalyticsCharts();
  initSensorGraphs();
  initFeedGenerator();
  initCodeDrawer();
  
  // Set initial language UI labels
  applyLanguageUI();
  
  setTimeout(() => {
    speakVoice(langLib[state.lang].headerTitle + " road safety ecosystem active. Firebase secure authorization database synchronized.");
  }, 1000);
});

// --- Simple Clock Widget ---
function initClock() {
  const updateTime = () => {
    const now = new Date();
    let hours = now.getHours();
    let minutes = now.getMinutes();
    hours = hours < 10 ? '0' + hours : hours;
    minutes = minutes < 10 ? '0' + minutes : minutes;
    document.getElementById('phoneTime').textContent = `${hours}:${minutes}`;
  };
  setInterval(updateTime, 1000);
  updateTime();
}

// --- Audio & Synth Systems ---
function initAudio() {
  const voiceToggle = document.getElementById('voiceToggle');
  voiceToggle.addEventListener('click', () => {
    state.voiceAssistant = !state.voiceAssistant;
    if (state.voiceAssistant) {
      voiceToggle.classList.remove('voice-off');
      speakVoice(state.lang === 'en' ? "Voice assistance enabled." : "குரல் உதவி இயக்கப்பட்டது.");
    } else {
      voiceToggle.classList.add('voice-off');
    }
  });
}

function playSound(type) {
  try {
    if (!state.audioCtx) {
      state.audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    const ctx = state.audioCtx;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    if (type === 'chirp') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(520, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1040, ctx.currentTime + 0.15);
      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.15);
      osc.start();
      osc.stop(ctx.currentTime + 0.15);
    } else if (type === 'beep') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(700, ctx.currentTime);
      gain.gain.setValueAtTime(0.1, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
      osc.start();
      osc.stop(ctx.currentTime + 0.2);
    }
  } catch(e) {}
}

let sirenIntervalId = null;
function startEmergencySiren() {
  if (sirenIntervalId) return;
  if (!state.audioCtx) {
    state.audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }
  const ctx = state.audioCtx;
  sirenIntervalId = setInterval(() => {
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = 'sine';
      osc.frequency.setValueAtTime(900, ctx.currentTime);
      osc.frequency.linearRampToValueAtTime(1300, ctx.currentTime + 0.25);
      osc.frequency.linearRampToValueAtTime(900, ctx.currentTime + 0.5);
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.48);
      osc.start();
      osc.stop(ctx.currentTime + 0.5);
    } catch(e) {}
  }, 500);
}

function stopEmergencySiren() {
  if (sirenIntervalId) {
    clearInterval(sirenIntervalId);
    sirenIntervalId = null;
  }
}

// --- Text-To-Speech Engine ---
function speakVoice(text) {
  if (!state.voiceAssistant) return;
  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.volume = 0.95;
    utterance.rate = 1.05;
    
    // Auto-detect voice language based on active language setting!
    const voices = window.speechSynthesis.getVoices();
    if (state.lang === 'ta') {
      // Find Tamil voice if supported on user machine
      const taVoice = voices.find(v => v.lang.includes("ta") || v.name.includes("Tamil") || v.name.includes("Lekha"));
      if (taVoice) utterance.voice = taVoice;
      utterance.lang = 'ta-IN';
    } else {
      const enVoice = voices.find(v => v.name.includes("Google US English") || v.name.includes("Zira") || v.lang === "en-US");
      if (enVoice) utterance.voice = enVoice;
      utterance.lang = 'en-US';
    }
    
    window.speechSynthesis.speak(utterance);
  } catch(e) {}
}

// --- Multi-Language Toggle Switch ---
window.toggleLanguage = function(langCode) {
  state.lang = langCode;
  document.getElementById('langEn').classList.remove('active');
  document.getElementById('langTa').classList.remove('active');
  
  if (langCode === 'en') {
    document.getElementById('langEn').classList.add('active');
  } else {
    document.getElementById('langTa').classList.add('active');
  }
  
  applyLanguageUI();
  playSound('chirp');
  
  const greet = langCode === 'en' ? "Language set to English." : "மொழியை தமிழுக்கு மாற்றியுள்ளீர்கள்.";
  speakVoice(greet);
};

function applyLanguageUI() {
  const dictionary = langLib[state.lang];
  Object.keys(dictionary).forEach(key => {
    const element = document.getElementById(key);
    if (element) {
      if (element.tagName === 'INPUT') {
        element.placeholder = dictionary[key];
      } else {
        element.innerHTML = dictionary[key];
      }
    }
  });
}

// --- Firebase Mock Login Trigger ---
window.simulateFirebaseLogin = function() {
  playSound('chirp');
  
  // Animate loading inside the screen
  const loginBtn = document.querySelector('.btn-login-submit');
  loginBtn.innerHTML = `<i class="fa-solid fa-circle-notch fa-spin"></i> Firebase Auth...`;
  
  speakVoice(state.lang === 'en' ? "Firebase persistent login session verified." : "ஃபயர்பேஸ் மூலம் பாதுகாப்பான உள்நுழைவு அங்கீகரிக்கப்பட்டது.");
  
  setTimeout(() => {
    // Show navigation bar inside phone
    document.getElementById('phoneNavBar').style.display = 'flex';
    // Switch to Home Page
    switchMobileScreen('screenHome');
    loginBtn.innerHTML = `<i class="fa-solid fa-arrow-right-to-bracket" style="margin-right: 8px;"></i> Sign In`;
  }, 1200);
};

// --- Mobile Screen Switcher ---
window.switchMobileScreen = function(screenId) {
  const currentActive = document.querySelector('.mobile-screen.active');
  if (currentActive) {
    currentActive.classList.remove('active');
  }
  
  const targetScreen = document.getElementById(screenId);
  targetScreen.classList.add('active');
  state.activeMobileScreen = screenId;
  
  // Highlight bottom navigation icons if switching standard screens
  const navBtns = document.querySelectorAll('.phone-nav-bar .nav-item');
  navBtns.forEach(btn => btn.classList.remove('active'));
  
  if (screenId === 'screenHome') {
    navBtns[0].classList.add('active');
    stopCameraAiMode();
  } else if (screenId === 'screenPothole') {
    navBtns[1].classList.add('active');
    stopCameraAiMode();
    setTimeout(() => {
      if (state.leafletMap) state.leafletMap.invalidateSize();
    }, 200);
  } else if (screenId === 'screenAiVision') {
    navBtns[2].classList.add('active');
    startCameraAiMode();
  } else if (screenId === 'screenTelemetry') {
    navBtns[3].classList.add('active');
    stopCameraAiMode();
  } else {
    stopCameraAiMode();
  }
  
  playSound('chirp');
};

// --- Leaflet Map Engine ---
function initLeafletMap() {
  // Chennai center (Adyar)
  const chennaiCoords = [13.0012, 80.2565];
  state.leafletMap = L.map('mobileLeafletMap', {
    zoomControl: false,
    attributionControl: false
  }).setView(chennaiCoords, 13);
  
  L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
    maxZoom: 20
  }).addTo(state.leafletMap);
  
  // User Pin
  const userPinIcon = L.divIcon({
    className: 'custom-gps-pulse',
    iconSize: [16, 16],
    iconAnchor: [8, 8]
  });
  state.driverMarker = L.marker([13.0030, 80.2510], { icon: userPinIcon }).addTo(state.leafletMap);
  
  syncMapTickets();
  
  // Add new pothole geotag by clicking map inside phone
  state.leafletMap.on('click', (e) => {
    if (state.activeMobileScreen === 'screenPothole') {
      const lat = e.latlng.lat.toFixed(4);
      const lng = e.latlng.lng.toFixed(4);
      // Auto fill input coords or drop pin
      document.getElementById('potholeDescInput').value = `Pothole shock geotagged at coordinates [${lat}, ${lng}].`;
      L.marker([lat, lng], {
        icon: L.divIcon({
          className: 'pothole-marker-icon',
          html: '<i class="fa-solid fa-location-crosshairs"></i>',
          iconSize: [20, 20],
          iconAnchor: [10, 10]
        })
      }).addTo(state.leafletMap);
      playSound('beep');
    }
  });
}

function syncMapTickets() {
  state.mapMarkers.forEach(m => state.leafletMap.removeLayer(m));
  state.mapMarkers = [];
  
  state.mockTickets.forEach(tkt => {
    let iconClass = 'pothole-marker-icon';
    let label = '<i class="fa-solid fa-road-barrier"></i>';
    
    if (tkt.urgency === 'CRITICAL' || tkt.type.includes('Wrong-side')) {
      iconClass = 'accident-marker-icon';
      label = '<i class="fa-solid fa-triangle-exclamation"></i>';
    }
    
    const customIcon = L.divIcon({
      className: iconClass,
      html: label,
      iconSize: [24, 24],
      iconAnchor: [12, 12]
    });
    
    const marker = L.marker([tkt.lat, tkt.lng], { icon: customIcon }).addTo(state.leafletMap);
    marker.bindPopup(`<b>${tkt.type}</b><br>${tkt.road}<br>AI Confidence: ${tkt.confidence}<br>Urgency: ${tkt.urgency}`);
    state.mapMarkers.push(marker);
  });
  
  renderAdminTicketsTable();
}

// Map obstacle warning trigger
function triggerMapObstacleWarning(text) {
  playSound('beep');
  speakVoice(text);
}

// --- Edge AI Vision Hub logic ---
let cvTimer = null;
let cameraActive = false;

function startCameraAiMode() {
  cameraActive = true;
  const video = document.getElementById('webcamFeed');
  const canvas = document.getElementById('cameraCanvas');
  const ctx = canvas.getContext('2d');
  
  navigator.mediaDevices.getUserMedia({ video: { width: 375, height: 250 } })
    .then(stream => {
      state.webcamStream = stream;
      video.srcObject = stream;
      video.style.display = 'block';
      state.webcamActive = true;
      runVisionOverlayLoop(ctx, canvas, video);
    })
    .catch(err => {
      video.style.display = 'none';
      state.webcamActive = false;
      runSimulatedVisionLoop(ctx, canvas);
    });
}

function stopCameraAiMode() {
  cameraActive = false;
  if (cvTimer) {
    cancelAnimationFrame(cvTimer);
    cvTimer = null;
  }
  if (state.webcamStream) {
    state.webcamStream.getTracks().forEach(track => track.stop());
    state.webcamStream = null;
  }
  state.webcamActive = false;
}

// 1. Scanning HUD when camera available
function runVisionOverlayLoop(ctx, canvas, video) {
  if (!cameraActive) return;
  canvas.width = 345;
  canvas.height = 250;
  ctx.clearRect(0,0, canvas.width, canvas.height);
  
  const w = canvas.width;
  const h = canvas.height;
  
  ctx.strokeStyle = 'hsla(48, 100%, 50%, 0.4)';
  ctx.lineWidth = 1.5;
  
  const boxX = w * 0.25;
  const boxY = h * 0.2;
  const boxW = w * 0.5;
  const boxH = h * 0.55;
  
  ctx.strokeRect(boxX, boxY, boxW, boxH);
  
  // caution corners
  ctx.fillStyle = 'var(--primary)';
  ctx.fillRect(boxX - 2, boxY - 2, 8, 2);
  ctx.fillRect(boxX - 2, boxY - 2, 2, 8);
  ctx.fillRect(boxX + boxW - 6, boxY - 2, 8, 2);
  ctx.fillRect(boxX + boxW, boxY - 2, 2, 8);
  
  // Laser line
  const scanLineY = (Math.sin(Date.now() / 300) * 0.5 + 0.5) * boxH + boxY;
  ctx.strokeStyle = 'var(--danger)';
  ctx.beginPath();
  ctx.moveTo(boxX, scanLineY);
  ctx.lineTo(boxX + boxW, scanLineY);
  ctx.stroke();
  
  // Simulated sign recognition overlay
  if (Math.sin(Date.now() / 2000) > 0.4) {
    ctx.strokeStyle = 'var(--primary)';
    ctx.strokeRect(20, 40, 70, 70);
    ctx.fillStyle = 'var(--primary)';
    ctx.font = '8px monospace';
    ctx.fillText("TRAFFIC SIGN: 60KM/H", 20, 35);
  }
  
  let ear = 0.31 + Math.sin(Date.now() / 1500) * 0.05;
  if (state.simulatedDrowsiness) {
    ear = 0.12 + Math.random() * 0.02;
    document.getElementById('earValue').textContent = ear.toFixed(2);
    document.getElementById('earValue').style.color = 'var(--danger)';
  } else {
    document.getElementById('earValue').textContent = ear.toFixed(2);
    document.getElementById('earValue').style.color = '#fff';
  }
  
  cvTimer = requestAnimationFrame(() => runVisionOverlayLoop(ctx, canvas, video));
}

// 2. Neon simulated Wireframe HUD
function runSimulatedVisionLoop(ctx, canvas) {
  if (!cameraActive) return;
  canvas.width = 345;
  canvas.height = 250;
  ctx.clearRect(0,0, canvas.width, canvas.height);
  
  const w = canvas.width;
  const h = canvas.height;
  
  ctx.fillStyle = '#050505';
  ctx.fillRect(0,0,w,h);
  
  // grid lines
  ctx.strokeStyle = 'rgba(255, 230, 0, 0.04)';
  ctx.lineWidth = 1;
  const grid = 20;
  for(let x=0; x<w; x+=grid) {
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
  }
  for(let y=0; y<h; y+=grid) {
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
  }
  
  // Draw simulated Wireframe face
  ctx.strokeStyle = 'var(--primary)';
  ctx.beginPath();
  const faceX = w / 2;
  const faceY = h / 2;
  ctx.ellipse(faceX, faceY, 55, 75, 0, 0, Math.PI * 2);
  ctx.stroke();
  
  const leftEyeX = faceX - 20;
  const rightEyeX = faceX + 20;
  const eyeY = faceY - 12;
  ctx.fillStyle = 'var(--primary)';
  ctx.beginPath(); ctx.arc(leftEyeX, eyeY, 4, 0, Math.PI*2); ctx.fill();
  ctx.beginPath(); ctx.arc(rightEyeX, eyeY, 4, 0, Math.PI*2); ctx.fill();
  
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
  ctx.beginPath();
  ctx.moveTo(leftEyeX, eyeY); ctx.lineTo(faceX, faceY);
  ctx.lineTo(rightEyeX, eyeY); ctx.lineTo(faceX, faceY - 40);
  ctx.lineTo(leftEyeX, eyeY); ctx.lineTo(faceX - 55, faceY);
  ctx.lineTo(faceX, faceY + 45); ctx.lineTo(faceX + 55, faceY);
  ctx.lineTo(rightEyeX, eyeY);
  ctx.stroke();
  
  // Traffic Sign Scanner Simulation inside phone
  if (Math.sin(Date.now() / 1500) > 0.3) {
    ctx.strokeStyle = 'var(--danger)';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(15, 25, 60, 50);
    ctx.fillStyle = 'var(--danger)';
    ctx.font = '8px monospace';
    ctx.fillText("SPEED SIGN: 60", 15, 20);
  }
  
  const scanLine = (Math.sin(Date.now() / 400) * 0.5 + 0.5) * h;
  const grad = ctx.createLinearGradient(0, scanLine - 25, 0, scanLine);
  grad.addColorStop(0, 'rgba(0,0,0,0)');
  grad.addColorStop(1, 'hsla(48, 100%, 50%, 0.2)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, scanLine - 25, w, 25);
  
  ctx.strokeStyle = 'var(--primary)';
  ctx.lineWidth = 2;
  ctx.beginPath(); ctx.moveTo(0, scanLine); ctx.lineTo(w, scanLine); ctx.stroke();
  
  ctx.fillStyle = 'hsla(0, 100%, 54%, 0.05)';
  ctx.strokeStyle = 'var(--danger)';
  ctx.strokeRect(w*0.12, h*0.08, w*0.76, h*0.84);
  
  ctx.fillStyle = 'var(--primary)';
  ctx.font = '7px monospace';
  ctx.fillText("NAMMAROAD OPENCV GRAPH SIMULATION", 45, 30);
  
  let ear = 0.32 + Math.sin(Date.now() / 1500) * 0.05;
  if (state.simulatedDrowsiness) {
    ear = 0.13 + Math.random() * 0.02;
    document.getElementById('earValue').textContent = ear.toFixed(2);
    document.getElementById('earValue').style.color = 'var(--danger)';
  } else {
    document.getElementById('earValue').textContent = ear.toFixed(2);
    document.getElementById('earValue').style.color = '#fff';
  }
  
  cvTimer = requestAnimationFrame(() => runSimulatedVisionLoop(ctx, canvas));
}

// Simulated drowsiness scan toggle
document.getElementById('mockPotholeVision').addEventListener('click', () => {
  state.simulatedDrowsiness = true;
  document.getElementById('fatigueBanner').classList.remove('alert-hidden');
  
  speakVoice(langLib[state.lang].drowsyVoiceSpeech);
  
  setTimeout(() => {
    state.simulatedDrowsiness = false;
    document.getElementById('fatigueBanner').classList.add('alert-hidden');
  }, 6000);
});

// Toggle camera
document.getElementById('toggleWebcam').addEventListener('click', () => {
  stopCameraAiMode();
  startCameraAiMode();
  speakVoice(state.lang === 'en' ? "Updating vision monitoring camera mode." : "ஏஐ கேமரா செட்டிங்ஸ் புதுப்பிக்கப்பட்டது.");
});

// --- Pothole Geotag report form submits ---
window.selectSeverity = function(sev) {
  state.activeSeverity = sev;
  document.querySelectorAll('.sev-btn').forEach(btn => btn.classList.remove('active'));
  
  const clickedBtn = document.getElementById('sev' + sev);
  if (clickedBtn) clickedBtn.classList.add('active');
  playSound('chirp');
};

window.simulatePhotoSelection = function() {
  playSound('chirp');
  const preview = document.getElementById('mockUploadedImage');
  const placeholder = document.getElementById('uploadPlaceholder');
  
  // Set mock pothole image
  preview.src = "https://images.unsplash.com/photo-1515162305285-0293e4767cc2?q=80&w=375&auto=format&fit=crop";
  preview.style.display = 'block';
  placeholder.style.display = 'none';
  speakVoice(state.lang === 'en' ? "Pothole photo captured and compressed successfully." : "புகைப்படம் எடுக்கப்பட்டு ஃபயர்பேஸில் பதிவேற்ற தயாராக உள்ளது.");
};

window.submitPotholeReport = function() {
  const desc = document.getElementById('potholeDescInput').value || "Road damage report";
  const userPin = state.driverMarker.getLatLng();
  
  // Add as active ticket
  const newId = 'TKT-' + Math.floor(1000 + Math.random() * 9000);
  const newReport = {
    id: newId,
    lat: userPin.lat,
    lng: userPin.lng,
    type: `${state.activeSeverity} Pothole`,
    confidence: '94%',
    urgency: state.activeSeverity.toUpperCase(),
    road: desc.substring(0, 24)
  };
  
  state.mockTickets.unshift(newReport);
  
  // Update admin KPI
  state.adminKPIs.potholes++;
  document.getElementById('kpiPotholes').textContent = state.adminKPIs.potholes;
  
  // Insert log in feed
  pushAlertToAdminFeed(
    'warning',
    `CITIZEN REPORT FIRESTORE`,
    `New road shock report ${newId} submitted by user Muthukumar. Geotag: ${userPin.lat.toFixed(4)}°, ${userPin.lng.toFixed(4)}°.`,
    'Just Now'
  );
  
  playSound('chirp');
  speakVoice(state.lang === 'en' ? "Report uploaded to Firebase Firestore database." : "உங்களது அறிக்கை மாநகராட்சி ஃபயர்பேஸ் சேமிப்பகத்தில் வெற்றிகரமாக பதிவேற்றப்பட்டது.");
  
  // Reset form
  document.getElementById('potholeDescInput').value = '';
  document.getElementById('mockUploadedImage').style.display = 'none';
  document.getElementById('uploadPlaceholder').style.display = 'flex';
  
  // Sync
  syncMapTickets();
  switchMobileScreen('screenHome');
};

// --- Telemetry & Sensor plots ---
function initSensorGraphs() {
  const length = 50;
  const valuesX = Array(length).fill(0);
  const valuesY = Array(length).fill(0);
  
  const drawWave = () => {
    if (state.activeMobileScreen === 'screenTelemetry') {
      const shock = state.sosTimerId ? (1.5 + Math.random() * 3.5) : (0.1 + Math.random() * 0.2);
      valuesX.shift(); valuesX.push(shock + Math.sin(Date.now() / 150) * 0.4);
      valuesY.shift(); valuesY.push(Math.cos(Date.now() / 200) * 0.3 + (Math.random() * 0.1));
      
      const mockSpeed = state.sosTimerId ? Math.max(0, parseInt(document.getElementById('dialSpeedNum').textContent) - 8) : 60 + Math.floor(Math.sin(Date.now() / 1000) * 5);
      document.getElementById('dialSpeedNum').textContent = mockSpeed;
      
      const canvas = document.getElementById('imuLiveChart');
      const ctx = canvas.getContext('2d');
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0,0,w,h);
      
      ctx.strokeStyle = 'var(--primary)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      for(let i=0; i<length; i++) {
        const x = (w / length) * i;
        const y = (h / 2) - (valuesX[i] * (h / 6));
        if (i===0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke();
      
      ctx.strokeStyle = 'var(--danger)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      for(let i=0; i<length; i++) {
        const x = (w / length) * i;
        const y = (h / 2) - (valuesY[i] * (h / 4));
        if (i===0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke();
      
      const gDot = document.getElementById('gDot');
      if (gDot) {
        const mX = Math.min(25, Math.max(-25, valuesY[length-1] * 25));
        const mY = Math.min(25, Math.max(-25, valuesX[length-1] * 12));
        gDot.style.transform = `translate(calc(-50% + ${mX}px), calc(-50% + ${mY}px))`;
        
        const gForceVal = (0.95 + valuesX[length-1] * 0.2).toFixed(2);
        document.getElementById('gValNum').textContent = `${gForceVal} G`;
      }
    }
    requestAnimationFrame(drawWave);
  };
  drawWave();
}

window.triggerCrashSimulation = function() {
  playSound('beep');
  state.sosCountdown = 10;
  
  document.getElementById('sosNormalView').style.display = 'none';
  document.getElementById('sosCountdownView').style.display = 'flex';
  document.getElementById('sosCountdownNum').textContent = state.sosCountdown;
  
  speakVoice(langLib[state.lang].sosVoiceSpeech);
  startEmergencySiren();
  
  state.sosTimerId = setInterval(() => {
    state.sosCountdown--;
    document.getElementById('sosCountdownNum').textContent = state.sosCountdown;
    
    // Pulse screen borders in phone
    document.getElementById('phoneScreen').style.boxShadow = `inset 0 0 ${20 + (10 - state.sosCountdown)*5}px rgba(255,0,0,0.85)`;
    
    if (state.sosCountdown <= 0) {
      clearInterval(state.sosTimerId);
      state.sosTimerId = null;
      executeEmergencySOSDispatch();
    } else {
      playSound('beep');
    }
  }, 1000);
};

window.cancelCrashSimulation = function() {
  if (state.sosTimerId) {
    clearInterval(state.sosTimerId);
    state.sosTimerId = null;
  }
  stopEmergencySiren();
  document.getElementById('phoneScreen').style.boxShadow = 'none';
  document.getElementById('sosNormalView').style.display = 'block';
  document.getElementById('sosCountdownView').style.display = 'none';
  
  speakVoice(state.lang === 'en' ? "Emergency broadcast canceled." : "அவசர உதவி சிக்னல் ரத்து செய்யப்பட்டது.");
};

function executeEmergencySOSDispatch() {
  stopEmergencySiren();
  document.getElementById('phoneScreen').style.boxShadow = 'none';
  document.getElementById('sosCountdownView').style.display = 'none';
  document.getElementById('sosDispatchedView').style.display = 'flex';
  
  pushAlertToAdminFeed(
    'danger',
    'CRITICAL IMPACT DISPATCHED',
    'Severe vehicle collision telemetry transmitted near Chennai Interchange. Rescue team en route.',
    'Just Now'
  );
  
  state.adminKPIs.rescues++;
  document.getElementById('kpiRescues').textContent = state.adminKPIs.rescues;
  
  speakVoice(state.lang === 'en' ? "Golden Hour emergency rescuers dispatched. Location transmitted." : "விபத்து மீட்பு ஆம்புலன்ஸ் அனுப்பப்பட்டது. உங்கள் இருப்பிடம் பகிரப்பட்டது.");
}

window.resetSosView = function() {
  document.getElementById('sosDispatchedView').style.display = 'none';
  document.getElementById('sosNormalView').style.display = 'block';
};

// --- Floating SOS Radar beacon popup systems ---
window.toggleFloatingSosRadar = function() {
  const radar = document.getElementById('emergencyRadarPopup');
  radar.classList.toggle('show');
  
  if (radar.classList.contains('show')) {
    playSound('beep');
    speakVoice(state.lang === 'en' ? "SOS radar beacon pulsing. Finding nearby Chennai traffic patrols." : "அவசர சிக்னல் ஒளிபரப்பப்படுகிறது. அருகிலுள்ள காவல் நிலையங்கள் தேடப்படுகின்றன.");
  }
};

window.closeFloatingSosRadar = function() {
  document.getElementById('emergencyRadarPopup').classList.remove('show');
  playSound('chirp');
};

window.callPolice = function() {
  playSound('chirp');
  speakVoice(state.lang === 'en' ? "Dialing Chennai Traffic police officer." : "போக்குவரத்து காவல் அவசர எண்ணை தொடர்பு கொள்கிறது.");
};

// --- Municipality Analytics & Charts ---
let adminCatChart = null;
let adminTrendChart = null;

function initAnalyticsCharts() {
  const catCtx = document.getElementById('adminCategoryChart').getContext('2d');
  const trendCtx = document.getElementById('adminTrendChart').getContext('2d');
  
  Chart.defaults.color = 'hsl(0, 0%, 75%)';
  Chart.defaults.font.family = 'Inter';
  
  adminCatChart = new Chart(catCtx, {
    type: 'doughnut',
    data: {
      labels: ['Potholes', 'Speed Offenses', 'Crash Alerts', 'Wrong-side Driving'],
      datasets: [{
        data: [45, 20, 15, 20],
        backgroundColor: [
          'hsl(48, 100%, 50%)',  // Yellow
          'hsl(28, 100%, 50%)',  // Orange
          'hsl(0, 100%, 54%)',   // Red
          'hsl(200, 100%, 55%)'  // Info Blue
        ],
        borderWidth: 0
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'right',
          labels: { boxWidth: 10, font: { size: 10 } }
        }
      }
    }
  });
  
  adminTrendChart = new Chart(trendCtx, {
    type: 'bar',
    data: {
      labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
      datasets: [{
        label: 'G-Force Telemetry Anomaly Spikes',
        data: [14, 18, 5, 8, 3, 28, 18],
        backgroundColor: 'hsla(48, 100%, 50%, 0.65)',
        borderColor: 'hsl(48, 100%, 50%)',
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: { grid: { color: 'rgba(255,255,255,0.05)' } },
        x: { grid: { color: 'rgba(255,255,255,0.05)' } }
      },
      plugins: {
        legend: { display: false }
      }
    }
  });
}

function renderAdminTicketsTable() {
  const tbody = document.getElementById('adminTicketTableBody');
  tbody.innerHTML = '';
  
  state.mockTickets.forEach((tkt) => {
    const tr = document.createElement('tr');
    let uClass = 'priority-low';
    if (tkt.urgency === 'CRITICAL') uClass = 'priority-high';
    else if (tkt.urgency === 'HIGH' || tkt.urgency === 'MEDIUM') uClass = 'priority-medium';
    
    tr.innerHTML = `
      <td><span class="ticket-id">${tkt.id}</span></td>
      <td>${tkt.lat.toFixed(4)}°, ${tkt.lng.toFixed(4)}° (${tkt.road})</td>
      <td>${tkt.type}</td>
      <td><i class="fa-solid fa-brain" style="color:var(--primary); margin-right:5px;"></i>${tkt.confidence}</td>
      <td><span class="badge-priority ${uClass}">${tkt.urgency}</span></td>
      <td>
        <button class="btn btn-outline btn-xs" onclick="resolveTicket('${tkt.id}')">
          <i class="fa-solid fa-circle-check"></i> Fix Road
        </button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

window.resolveTicket = function(id) {
  const index = state.mockTickets.findIndex(t => t.id === id);
  if (index !== -1) {
    const tkt = state.mockTickets[index];
    playSound('chirp');
    
    pushAlertToAdminFeed(
      'success',
      `TICKET RESTORED: ${id}`,
      `NammaRoad maintenance crews filled asphalts successfully at ${tkt.road}.`,
      'Just Now'
    );
    
    state.mockTickets.splice(index, 1);
    
    state.adminKPIs.potholes--;
    state.adminKPIs.repairs++;
    document.getElementById('kpiPotholes').textContent = state.adminKPIs.potholes;
    document.getElementById('kpiRepairs').textContent = state.adminKPIs.repairs;
    
    state.adminKPIs.safetyIndex = Math.min(100.0, state.adminKPIs.safetyIndex + 0.18);
    document.getElementById('kpiSafetyIndex').textContent = `${state.adminKPIs.safetyIndex.toFixed(1)}%`;
    
    speakVoice(state.lang === 'en' ? `Road maintenance order ${id} completed.` : `சாலை பழுதுபார்ப்பு டிக்கெட் ${id} வெற்றிகரமாக சரிசெய்யப்பட்டது.`);
    
    syncMapTickets();
  }
};

window.autoGeneratePotholeTicket = function() {
  const cLat = 12.9800 + (Math.random() * 0.05);
  const cLng = 80.2300 + (Math.random() * 0.04);
  const newId = 'TKT-' + Math.floor(1000 + Math.random() * 9000);
  
  const mockP = {
    id: newId,
    lat: cLat,
    lng: cLng,
    type: 'Critical Pothole',
    confidence: '93%',
    urgency: 'HIGH',
    road: 'Automated OpenCV Geotag'
  };
  
  state.mockTickets.unshift(mockP);
  state.adminKPIs.potholes++;
  document.getElementById('kpiPotholes').textContent = state.adminKPIs.potholes;
  
  pushAlertToAdminFeed(
    'warning',
    `AI GEOTAG CAPTURED`,
    `OpenCV road scan logged a new pavement G-Shock violation at ${cLat.toFixed(4)}°, ${cLng.toFixed(4)}°.`,
    'Just Now'
  );
  
  triggerMapObstacleWarning(langLib[state.lang].gpsMockAlert);
  syncMapTickets();
};

// --- Live Ticker logs generators ---
function initFeedGenerator() {
  const initialAlerts = [
    { type: 'info', title: 'DRIVER ONLINE', desc: 'Muthukumar initiated secure Firebase auth travel session.', time: '2 mins ago' },
    { type: 'warning', title: 'POTHOLE DETECTED', desc: 'Camera vision logged a pothole hazard at Poonamallee Rd.', time: '8 mins ago' },
    { type: 'danger', title: 'DRIVER FATIGUE', desc: 'MediaPipe Eye tracking logged drowsiness state. spoken warning alert played.', time: '15 mins ago' }
  ];
  
  const feedList = document.getElementById('adminFeedList');
  initialAlerts.forEach(alert => {
    pushAlertToAdminFeed(alert.type, alert.title, alert.desc, alert.time);
  });
  
  setInterval(() => {
    const events = [
      { type: 'warning', title: 'Pothole Edge AI Vision', desc: 'TFLite YOLOv8 registered pavement crack G-Spike shock.', tText: langLib[state.lang].gpsMockAlert },
      { type: 'info', title: 'Driver Gamification', desc: 'User Muthukumar rewarded 40 RG tokens for zero speed violations.', tText: 'Tokens Awarded' },
      { type: 'warning', title: 'IMU Telemetry Anomaly', desc: 'Driver experienced a G-Force shock rating of 2.1Gs in Adyar.', tText: 'Telemetry shock spike' }
    ];
    const pick = events[Math.floor(Math.random() * events.length)];
    pushAlertToAdminFeed(pick.type, pick.title, pick.desc, 'Just Now');
    playSound('beep');
    
    if (state.activeMobileScreen === 'screenPothole' && pick.title.includes('YOLOv8')) {
      triggerMapObstacleWarning(pick.tText);
    }
  }, 20000);
}

function pushAlertToAdminFeed(type, title, desc, time) {
  const feedList = document.getElementById('adminFeedList');
  const item = document.createElement('div');
  item.className = 'feed-item';
  
  let iconClass = 'info';
  let icon = 'fa-circle-info';
  
  if (type === 'danger') { iconClass = 'danger'; icon = 'fa-triangle-exclamation'; }
  else if (type === 'warning') { iconClass = 'warning'; icon = 'fa-triangle-exclamation'; }
  else if (type === 'success') { iconClass = 'success'; icon = 'fa-circle-check'; }
  
  item.innerHTML = `
    <div class="feed-item-icon ${iconClass}">
      <i class="fa-solid ${icon}"></i>
    </div>
    <div class="feed-item-details">
      <div class="feed-item-title">
        <span>${title}</span>
        <span class="feed-item-time">${time}</span>
      </div>
      <p class="feed-item-desc">${desc}</p>
    </div>
  `;
  
  feedList.insertBefore(item, feedList.firstChild);
  if (feedList.childNodes.length > 20) {
    feedList.removeChild(feedList.lastChild);
  }
}

// --- Flutter Dart Source Code Drawer ---
const flutterSourceCodes = {
  flutterApp: `import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'sensor_handler.dart';
import 'ai_detector.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(); // Secure Firebase Auth Initialization
  runApp(const NammaRoadApp());
}

class NammaRoadApp extends StatelessWidget {
  const NammaRoadApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NammaRoad — Safer Roads',
      theme: ThemeData.dark().copyWith(
        primaryColor: const Color(0xFFFFE600), // Caution Traffic Yellow
        scaffoldBackgroundColor: const Color(0xFF000000), // Minimal Black
      ),
      home: const LoginScreen(),
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  void _signInWithFirebase() async {
    try {
      // Secure Authentication login sequence
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const HomeScreen()));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Auth Failed: $e")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Card(
          color: const Color(0xFF111111),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text("NammaRoad", style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
                TextField(controller: _emailController, decoration: const InputDecoration(labelText: 'Email')),
                TextField(controller: _passwordController, obscureText: true, decoration: const InputDecoration(labelText: 'Password')),
                ElevatedButton(onPressed: _signInWithFirebase, child: const Text("Sign In")),
              ],
            ),
          ),
        ),
      ),
    );
  }
}`,
  flutterSensors: `import 'dart:async';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:math';

class SensorHandler {
  StreamSubscription? _accelerometerSub;
  final Function(double) onCrashAlertTriggered;

  SensorHandler({required this.onCrashAlertTriggered});

  void startMonitoring() {
    // Listen to smartphone Accelerometer for road bumps and crashes
    _accelerometerSub = userAccelerometerEvents.listen((UserAccelerometerEvent event) {
      double gForce = sqrt(event.x * event.x + event.y * event.y + event.z * event.z) / 9.80665;
      
      // CRITICAL ROAD CRASH ANOMALY: If impact G exceeds 6.5Gs threshold index
      if (gForce > 6.5) {
        onCrashAlertTriggered(gForce);
        _uploadCrashToFirestore(gForce);
      }
    });
  }

  void _uploadCrashToFirestore(double gForce) async {
    // secure Firebase Geotag push to Municipality fleet
    await FirebaseFirestore.instance.collection('emergency_alerts').add({
      'impact_force': gForce,
      'timestamp': FieldValue.serverTimestamp(),
      'latitude': 13.0827,
      'longitude': 80.2707,
      'status': 'Dispatched'
    });
  }

  void stop() {
    _accelerometerSub?.cancel();
  }
}`,
  flutterVision: `import 'package:flutter/material.dart';
import 'package:tflite_flutter/tflite_flutter.dart';

class AIDetector {
  late Interpreter _tfliteInterpreter;
  bool _isModelLoaded = false;

  Future<void> loadModels() async {
    try {
      // Load compact YOLOv8 Nano edge weights
      _tfliteInterpreter = await Interpreter.fromAsset('nammaroad_yolov8.tflite');
      _isModelLoaded = true;
    } catch (e) {
      debugPrint("Error loading edge model weights: $e");
    }
  }

  void runEdgeInference(var inputFrameBytes) {
    if (!_isModelLoaded) return;
    
    // Execute OpenCV preprocessing matrices
    // Run drowsiness EAR aspect classifications
    // var outputs = List.filled(1 * 84 * 8400, 0).reshape([1, 84, 8400]);
    // _tfliteInterpreter.run(inputFrameBytes, outputs);
  }
}`
};

function initCodeDrawer() {
  const drawer = document.getElementById('codeDrawer');
  const toggle = document.getElementById('codeDrawerToggle');
  
  toggle.addEventListener('click', () => {
    drawer.classList.toggle('expanded');
    if (drawer.classList.contains('expanded')) {
      renderActiveCode();
    }
  });
  
  renderActiveCode();
}

window.switchCodeTab = function(tabId) {
  state.activeCodeTab = tabId;
  document.querySelectorAll('.code-tab').forEach(el => el.classList.remove('active'));
  
  const clicked = document.querySelector(`.code-tab[onclick*="${tabId}"]`);
  if (clicked) clicked.classList.add('active');
  
  renderActiveCode();
  playSound('chirp');
};

function renderActiveCode() {
  const code = flutterSourceCodes[state.activeCodeTab];
  document.getElementById('codeBlock').textContent = code;
}

window.copyFlutterCode = function() {
  const code = flutterSourceCodes[state.activeCodeTab];
  navigator.clipboard.writeText(code).then(() => {
    speakVoice(state.lang === 'en' ? "Flutter Code copied to clipboard." : "ஃப்ளட்டர் சோர்ஸ் கோட் கிளிப்போர்டில் நகலெடுக்கப்பட்டது.");
    alert("Flutter Source Code Copied!");
  });
};
