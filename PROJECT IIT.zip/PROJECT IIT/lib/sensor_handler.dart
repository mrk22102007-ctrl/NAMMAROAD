import 'dart:async';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'dart:math';

class SensorHandler {
  StreamSubscription? _accelerometerSub;
  final Function(double) onCrashAlertTriggered;

  SensorHandler({required this.onCrashAlertTriggered});

  void startMonitoring() {
    // Listen to smartphone Accelerometer for road bumps and crash shocks
    _accelerometerSub = userAccelerometerEvents.listen((UserAccelerometerEvent event) {
      // Calculate resulting vector G-Force magnitude
      double gForce = sqrt(event.x * event.x + event.y * event.y + event.z * event.z) / 9.80665;
      
      // CRITICAL CRASH TRIGGER: If impact G exceeds 6.5Gs threshold index
      if (gForce > 6.5) {
        onCrashAlertTriggered(gForce);
        _uploadCrashToFirestore(gForce);
      }
    });
  }

  void _uploadCrashToFirestore(double gForce) async {
    try {
      // Pushes a secure Geotag document to NammaRoad Firestore collection
      await FirebaseFirestore.instance.collection('emergency_alerts').add({
        'impact_force': gForce,
        'timestamp': FieldValue.serverTimestamp(),
        'latitude': 13.0827, // Mock or real GPS position
        'longitude': 80.2707,
        'status': 'Dispatched',
        'device_user': 'Muthukumar S',
      });
    } catch (e) {
      // Log Firestore connection fallback offline cache
      print("Firebase offline database caching active: $e");
    }
  }

  void stopMonitoring() {
    _accelerometerSub?.cancel();
  }
}
